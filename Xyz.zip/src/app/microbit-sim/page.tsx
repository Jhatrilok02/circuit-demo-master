"use client";
import MicrobitSimulatorPanel from "@/python_code_editor/components/MicrobitSimulatorPanel";

export default function MicrobitSimPage() {
  return <MicrobitSimulatorPanel />;
}
