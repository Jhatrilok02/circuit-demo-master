Project configuration instructions :

Step1 - Open the project directory inside the Visual Studio.
Step2 - Inside terminal (Ctrl + J), type the following commands :
    - pnpm install (command 1, for installation of all the dependencies)
    - pnpm dev (command 2, for running the project)