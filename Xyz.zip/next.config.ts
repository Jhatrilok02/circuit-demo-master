const nextConfig = {
  webpack(config: any) {
    return config;
  },
};

export default nextConfig;
